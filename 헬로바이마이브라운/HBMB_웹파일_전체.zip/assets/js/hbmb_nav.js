/**
 * HelloByMyBrown — 공통 하단 네비게이션 v1.0
 * 모든 페이지 </body> 직전에 <script src="hbmb_nav.js"></script> 삽입
 * 현재 페이지 자동 감지 → 활성 탭 표시
 */

(function() {

  // ── 현재 페이지 감지 ──────────────────────────
  const page = location.pathname.split('/').pop() || 'HOME_MAIN.html';

  // ── 탭 정의 ──────────────────────────────────
  const TABS = [
    { id:'home',   icon:'🏠', label:'홈',       href:'HOME_MAIN.html',  pages:['HOME_MAIN.html','hello_main.html'] },
    { id:'breed',  icon:'🔬', label:'견종백과',  href:'BREED_CARD.html', pages:['BREED_CARD.html','BREED_SIMPLE_REPORT.html','BREED_DETAIL_REPORT.html'] },
    { id:'ppic',   icon:'🧪', label:'PPIC',      href:'PPIC_QUIZ.html',  pages:['PPIC_QUIZ.html','PPIC_SIMPLE_REPORT.html','PPIC_DETAIL_REPORT.html'] },
    { id:'health', icon:'🏥', label:'헬스가이드',href:'HEALTH_GUIDE.html',pages:['HEALTH_GUIDE.html'] },
    { id:'more',   icon:'···',label:'더보기',    href:'#',               pages:['CALCULATOR.html','INFO_DESK.html','MY_PROFILE.html'] },
  ];

  // ── 더보기 메뉴 ──────────────────────────────
  const MORE_MENU = [
    { icon:'🧮', label:'계산기',      href:'CALCULATOR.html' },
    { icon:'🗺️', label:'동물병원·미용실', href:'INFO_DESK.html' },
    { icon:'👤', label:'마이프로필',  href:'MY_PROFILE.html' },
  ];

  // ── 활성 탭 판별 ─────────────────────────────
  function getActiveTab() {
    for (const t of TABS) {
      if (t.pages.includes(page)) return t.id;
    }
    return 'home';
  }
  const activeId = getActiveTab();

  // ── CSS 주입 ─────────────────────────────────
  const style = document.createElement('style');
  style.textContent = `
    /* 하단 네비 여백 확보 */
    body { padding-bottom: 72px; }

    /* ── 하단 네비 바 ── */
    #hbmb-nav {
      position: fixed; bottom: 0; left: 0; right: 0;
      background: rgba(251,247,242,0.97);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border-top: 1px solid #EDE4D8;
      z-index: 100;
      max-width: 480px;
      margin: 0 auto;
    }
    #hbmb-nav-inner {
      display: flex;
      height: 62px;
    }
    .hbmb-tab {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 3px;
      border: none;
      background: none;
      cursor: pointer;
      padding: 8px 4px;
      transition: transform 0.15s;
      text-decoration: none;
      -webkit-tap-highlight-color: transparent;
    }
    .hbmb-tab:active { transform: scale(0.92); }
    .hbmb-tab-icon {
      font-size: 22px;
      line-height: 1;
      transition: transform 0.2s;
    }
    .hbmb-tab.active .hbmb-tab-icon {
      transform: translateY(-2px);
    }
    /* 더보기 아이콘 특별 처리 */
    .hbmb-tab-icon.more-icon {
      font-size: 16px;
      font-weight: 700;
      color: #9B8878;
      font-family: 'Noto Sans KR', sans-serif;
      letter-spacing: 1px;
    }
    .hbmb-tab-label {
      font-size: 10px;
      font-weight: 700;
      color: #9B8878;
      font-family: 'Noto Sans KR', sans-serif;
      white-space: nowrap;
    }
    .hbmb-tab.active .hbmb-tab-label {
      color: #2E1F14;
    }
    /* 활성 탭 인디케이터 */
    .hbmb-tab.active::before {
      content: '';
      position: absolute;
      top: 0;
      width: 28px;
      height: 2px;
      background: #C9A84C;
      border-radius: 0 0 3px 3px;
    }
    .hbmb-tab {
      position: relative;
    }

    /* ── 더보기 드로어 ── */
    #hbmb-more-drawer {
      position: fixed;
      bottom: 62px; left: 0; right: 0;
      max-width: 480px;
      margin: 0 auto;
      background: #fff;
      border-top: 1px solid #EDE4D8;
      border-radius: 22px 22px 0 0;
      box-shadow: 0 -8px 32px rgba(46,31,20,0.12);
      z-index: 99;
      transform: translateY(100%);
      transition: transform 0.3s cubic-bezier(0.4,0,0.2,1);
      padding: 20px 20px 16px;
    }
    #hbmb-more-drawer.open {
      transform: translateY(0);
    }
    .hbmb-drawer-handle {
      width: 36px; height: 4px;
      background: #EDE4D8;
      border-radius: 2px;
      margin: 0 auto 18px;
    }
    .hbmb-drawer-title {
      font-size: 11px;
      letter-spacing: 2px;
      color: #C9A84C;
      font-weight: 700;
      margin-bottom: 14px;
      font-family: 'Noto Sans KR', sans-serif;
    }
    .hbmb-more-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 10px;
    }
    .hbmb-more-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      padding: 18px 10px;
      border-radius: 18px;
      background: #FBF7F2;
      border: 1.5px solid #EDE4D8;
      text-decoration: none;
      cursor: pointer;
      transition: all 0.2s;
      -webkit-tap-highlight-color: transparent;
    }
    .hbmb-more-item:hover,
    .hbmb-more-item:active {
      background: #2E1F14;
      border-color: #2E1F14;
    }
    .hbmb-more-item:hover .hbmb-more-label,
    .hbmb-more-item:active .hbmb-more-label {
      color: #fff;
    }
    .hbmb-more-icon { font-size: 26px; }
    .hbmb-more-label {
      font-size: 12px;
      font-weight: 700;
      color: #3D2B1F;
      text-align: center;
      font-family: 'Noto Sans KR', sans-serif;
      line-height: 1.3;
    }
    /* 현재 더보기 페이지 활성 표시 */
    .hbmb-more-item.current {
      background: #2E1F14;
      border-color: #2E1F14;
    }
    .hbmb-more-item.current .hbmb-more-label { color: #fff; }

    /* ── 드로어 오버레이 ── */
    #hbmb-overlay {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.3);
      z-index: 98;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s;
    }
    #hbmb-overlay.show {
      opacity: 1;
      pointer-events: all;
    }
  `;
  document.head.appendChild(style);

  // ── 하단 네비 HTML 생성 ───────────────────────
  const nav = document.createElement('div');
  nav.id = 'hbmb-nav';

  nav.innerHTML = `
    <div id="hbmb-nav-inner">
      ${TABS.map(t => {
        const isActive = t.id === activeId;
        const isMore   = t.id === 'more';
        const isMoreActive = t.pages.includes(page);
        return `
          <button
            class="hbmb-tab ${isActive || isMoreActive ? 'active' : ''}"
            onclick="${isMore ? 'toggleMore(event)' : `navTo('${t.href}')`}"
            id="hbmb-tab-${t.id}">
            <span class="hbmb-tab-icon ${isMore ? 'more-icon' : ''}">${t.icon}</span>
            <span class="hbmb-tab-label">${t.label}</span>
          </button>`;
      }).join('')}
    </div>
  `;
  document.body.appendChild(nav);

  // ── 더보기 드로어 ─────────────────────────────
  const drawer = document.createElement('div');
  drawer.id = 'hbmb-more-drawer';
  drawer.innerHTML = `
    <div class="hbmb-drawer-handle"></div>
    <div class="hbmb-drawer-title">MORE MENU</div>
    <div class="hbmb-more-grid">
      ${MORE_MENU.map(m => `
        <a class="hbmb-more-item ${page === m.href ? 'current' : ''}"
          href="${m.href}">
          <span class="hbmb-more-icon">${m.icon}</span>
          <span class="hbmb-more-label">${m.label}</span>
        </a>`).join('')}
    </div>
  `;
  document.body.appendChild(drawer);

  // ── 오버레이 ─────────────────────────────────
  const overlay = document.createElement('div');
  overlay.id = 'hbmb-overlay';
  overlay.onclick = closeMore;
  document.body.appendChild(overlay);

  // ── 함수 ─────────────────────────────────────
  window.navTo = function(href) {
    closeMore();
    window.location.href = href;
  };

  let moreOpen = false;
  window.toggleMore = function(e) {
    e.stopPropagation();
    moreOpen ? closeMore() : openMore();
  };

  function openMore() {
    moreOpen = true;
    document.getElementById('hbmb-more-drawer').classList.add('open');
    document.getElementById('hbmb-overlay').classList.add('show');
    document.getElementById('hbmb-tab-more').classList.add('active');
  }

  function closeMore() {
    moreOpen = false;
    document.getElementById('hbmb-more-drawer').classList.remove('open');
    document.getElementById('hbmb-overlay').classList.remove('show');
    if (activeId !== 'more' && !TABS.find(t=>t.id==='more').pages.includes(page)) {
      document.getElementById('hbmb-tab-more').classList.remove('active');
    }
  }
  window.closeMore = closeMore;

})();
