/**
 * HelloByMyBrown — 공유 프로필 엔진 v1.0
 * 모든 페이지 <head> 안에 <script src="hbmb_profile.js"></script> 로 삽입
 * localStorage key: 'hbmb_profile'
 */

const HBMB = (() => {

  // ── 생애주기 4단계 (전 메뉴 통일) ──────────────────────
  const STAGES = [
    { id:'puppy',  label:'퍼피',          en:'Puppy',        icon:'🐣', desc:'0~12개월' },
    { id:'young',  label:'영 어덜트',     en:'Young Adult',  icon:'🐾', desc:'1~3년'   },
    { id:'mature', label:'마추어 어덜트', en:'Mature Adult', icon:'🐕', desc:'3~8년'   },
    { id:'senior', label:'시니어',        en:'Senior',       icon:'🌿', desc:'8년+'    },
  ];

  // 사이즈별 나이 → 생애주기 기준
  const STAGE_AGE = {
    small:  { puppy:[0,1], young:[1,3],  mature:[3,10], senior:[10,99] },
    medium: { puppy:[0,1], young:[1,3],  mature:[3,9],  senior:[9,99]  },
    large:  { puppy:[0,1], young:[1,2],  mature:[2,7],  senior:[7,99]  },
  };

  // 나이 → 생애주기 자동 판별
  function ageToStage(years, size='small') {
    const tbl = STAGE_AGE[size] || STAGE_AGE.small;
    for (const [id,[mn,mx]] of Object.entries(tbl)) {
      if (years >= mn && years < mx) return id;
    }
    return 'senior';
  }

  // 견종 기본 데이터 (사이즈·이상체중 자동 매핑)
  const BREED_DATA = {
    '말티즈':       { size:'small',  idealWeight:3.5  },
    '푸들(토이)':   { size:'small',  idealWeight:3.5  },
    '치와와':       { size:'small',  idealWeight:2.5  },
    '포메라니안':   { size:'small',  idealWeight:3.0  },
    '비숑프리제':   { size:'small',  idealWeight:5.5  },
    '시츄':         { size:'small',  idealWeight:7.0  },
    '닥스훈트':     { size:'small',  idealWeight:8.0  },
    '프렌치불독':   { size:'medium', idealWeight:12.0 },
    '웰시코기':     { size:'medium', idealWeight:13.0 },
    '비글':         { size:'medium', idealWeight:11.0 },
    '불독':         { size:'medium', idealWeight:23.0 },
    '보더콜리':     { size:'medium', idealWeight:17.0 },
    '골든리트리버': { size:'large',  idealWeight:30.0 },
    '래브라도':     { size:'large',  idealWeight:30.0 },
    '허스키':       { size:'large',  idealWeight:23.0 },
    '진돗개':       { size:'medium', idealWeight:20.0 },
    '사모예드':     { size:'large',  idealWeight:25.0 },
  };

  // ── CRUD ─────────────────────────────────────────────
  function load() {
    try { return JSON.parse(localStorage.getItem('hbmb_profile')) || null; }
    catch { return null; }
  }

  function save(data) {
    try {
      // 나이 → 생애주기 자동 계산 후 저장
      if (data.ageYears !== undefined && !data.stageManual) {
        data.stage = ageToStage(data.ageYears, data.size || 'small');
      }
      localStorage.setItem('hbmb_profile', JSON.stringify(data));
      return true;
    } catch { return false; }
  }

  function clear() { localStorage.removeItem('hbmb_profile'); }

  // ── 프로필 → 각 페이지 기본값 변환 ──────────────────
  function get() {
    const p = load();
    if (!p) return null;
    return {
      dogName:      p.dogName      || '우리 강아지',
      guardianNick: p.guardianNick || '보호자',
      avatar:       p.avatar       || '🐕',
      breed:        p.breed        || '',
      size:         p.size         || 'small',
      weight:       p.weight       || 5,
      ageYears:     p.ageYears     || 3,
      stage:        p.stage        || 'mature',
      gender:       p.gender       || 'male',
      neutered:     p.neutered     !== undefined ? p.neutered : false,
      idealWeight:  p.idealWeight  || (BREED_DATA[p.breed]?.idealWeight || p.weight || 5),
    };
  }

  // ── 공통 프로필 헤더 배너 렌더 ───────────────────────
  // 각 페이지 상단에 <div id="hbmbBanner"></div> 삽입 후 호출
  function renderBanner(containerId, opts={}) {
    const el = document.getElementById(containerId);
    if (!el) return;
    const p = get();

    injectCSS();

    if (p) {
      const st = STAGES.find(s=>s.id===p.stage) || STAGES[2];
      el.innerHTML = `
        <div class="hbmb-banner filled">
          <div class="hb-avatar">${p.avatar}</div>
          <div class="hb-info">
            <div class="hb-name">${p.dogName}
              <span class="hb-nick">with ${p.guardianNick}</span>
            </div>
            <div class="hb-detail">
              ${p.breed || '견종 미입력'} &nbsp;·&nbsp;
              ${st.icon} ${st.label} &nbsp;·&nbsp;
              ${p.weight}kg
            </div>
          </div>
          <button class="hb-btn" onclick="HBMB.goProfile()">수정</button>
        </div>`;
    } else {
      el.innerHTML = `
        <div class="hbmb-banner empty">
          <div class="hb-avatar">🐾</div>
          <div class="hb-info">
            <div class="hb-name">마이프로필을 등록하면</div>
            <div class="hb-detail">모든 페이지가 자동으로 맞춤 설정돼요</div>
          </div>
          <button class="hb-btn gold" onclick="HBMB.goProfile()">등록하기</button>
        </div>`;
    }
  }

  function goProfile() { window.location.href = 'MY_PROFILE.html'; }

  // ── 공통 생애주기 버튼 렌더 ──────────────────────────
  // <div id="hbmbStage"></div> 삽입 후 호출
  // onChangeFn: stage 바뀔 때 콜백
  function renderStageSelector(containerId, currentStage, onChangeFn) {
    const el = document.getElementById(containerId);
    if (!el) return;
    injectCSS();
    el.innerHTML = `
      <div class="hbmb-stage-row">
        ${STAGES.map(s=>`
          <button class="hb-stage-btn ${s.id===currentStage?'active':''}"
            id="hbStage_${s.id}"
            onclick="HBMB._stageClick('${containerId}','${s.id}')">
            <span class="hs-icon">${s.icon}</span>
            <span class="hs-name">${s.label}</span>
            <span class="hs-desc">${s.desc}</span>
          </button>`).join('')}
      </div>`;
    el._onChangeFn = onChangeFn;
  }

  function _stageClick(containerId, stageId) {
    const el = document.getElementById(containerId);
    el.querySelectorAll('.hb-stage-btn').forEach(b=>b.classList.remove('active'));
    document.getElementById('hbStage_'+stageId).classList.add('active');
    if (el._onChangeFn) el._onChangeFn(stageId);
  }

  // ── 공통 CSS 주입 ────────────────────────────────────
  function injectCSS() {
    if (document.getElementById('hbmb-style')) return;
    const s = document.createElement('style');
    s.id = 'hbmb-style';
    s.textContent = `
      /* ── 프로필 배너 ── */
      .hbmb-banner {
        display:flex; align-items:center; gap:12px;
        border-radius:16px; padding:13px 16px;
        margin-bottom:12px;
      }
      .hbmb-banner.filled {
        background:#fff;
        border:1.5px solid #EDE4D8;
        box-shadow:0 3px 14px rgba(46,31,20,0.07);
      }
      .hbmb-banner.empty {
        background:rgba(201,168,76,0.07);
        border:1.5px dashed rgba(201,168,76,0.5);
      }
      .hb-avatar { font-size:28px; flex-shrink:0; }
      .hb-info   { flex:1; min-width:0; }
      .hb-name   {
        font-size:14px; font-weight:700; color:#2E1F14;
        white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
      }
      .hb-nick   { font-size:11px; color:#9B8878; font-weight:400; margin-left:6px; }
      .hb-detail { font-size:11px; color:#9B8878; margin-top:3px; line-height:1.5; }
      .hb-btn {
        font-size:11px; font-weight:700;
        padding:6px 14px; border-radius:11px;
        border:none; cursor:pointer;
        font-family:'Noto Sans KR',sans-serif;
        white-space:nowrap; flex-shrink:0;
        background:#EDE4D8; color:#3D2B1F;
        transition:background 0.2s;
      }
      .hb-btn.gold { background:#C9A84C; color:#2E1F14; }
      .hb-btn:hover { opacity:0.85; }

      /* ── 생애주기 4단계 ── */
      .hbmb-stage-row {
        display:grid; grid-template-columns:repeat(4,1fr);
        gap:7px;
      }
      .hb-stage-btn {
        padding:10px 4px; border-radius:13px; border:1.5px solid #EDE4D8;
        background:#FBF7F2; cursor:pointer;
        display:flex; flex-direction:column; align-items:center; gap:3px;
        transition:all 0.2s; font-family:'Noto Sans KR',sans-serif;
      }
      .hb-stage-btn:hover { border-color:#C9A84C; }
      .hb-stage-btn.active {
        background:#2E1F14; border-color:#2E1F14; color:#fff;
      }
      .hs-icon { font-size:18px; }
      .hs-name { font-size:10px; font-weight:700; color:inherit; }
      .hb-stage-btn:not(.active) .hs-name { color:#3D2B1F; }
      .hs-desc { font-size:8px; color:#9B8878; }
      .hb-stage-btn.active .hs-desc { color:rgba(255,255,255,0.55); }
    `;
    document.head.appendChild(s);
  }

  // ── 공개 API ─────────────────────────────────────────
  return {
    STAGES, STAGE_AGE, BREED_DATA,
    ageToStage, load, save, clear, get,
    renderBanner, renderStageSelector,
    goProfile, injectCSS, _stageClick,
  };

})();
