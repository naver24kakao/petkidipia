/**
 * HelloByMyBrown — 워터마크 모듈 v1.0
 * ─────────────────────────────────────
 * Canvas 기반 실시간 개인화 워터마크
 * 설치 불필요 / 브라우저 내장 Canvas 사용
 * ─────────────────────────────────────
 * 사용법:
 *   <script src="hbmb_config.js"></script>
 *   <script src="hbmb_data.js"></script>
 *   <script src="hbmb_watermark.js"></script>
 *
 *   // 이미지에 워터마크 적용
 *   HBMB.watermark('001_02_puppy.png', 'img-target-id')
 *
 *   // 또는 직접 URL로
 *   HBMB.watermark(imageUrl, targetImgId)
 * ─────────────────────────────────────
 */

window.HBMB = window.HBMB || {};

// ══════════════════════════════════════
//  워터마크 설정
// ══════════════════════════════════════
const WM_CONFIG = {
  // 브랜드 텍스트
  brand     : 'HelloByMyBrown © 2026',

  // 폰트
  fontBrand : '500 13px Noto Sans KR, sans-serif',
  fontName  : 'bold 14px Noto Sans KR, sans-serif',

  // 색상 (반투명 화이트)
  colorBrand: 'rgba(255, 255, 255, 0.55)',
  colorName : 'rgba(255, 255, 255, 0.80)',

  // 위치 (우하단)
  paddingX  : 14,
  paddingY  : 14,

  // 배경 바 (반투명 다크)
  barColor  : 'rgba(46, 31, 20, 0.45)',
  barPadding: 8,
  barRadius : 8,
};

// ══════════════════════════════════════
//  메인 함수
//  HBMB.watermark(src, targetId, options)
//
//  src      : 이미지 URL 또는 파일명
//  targetId : 결과를 넣을 <img> 태그 id
//  options  : { dogName, guardianNick } 직접 전달 가능
// ══════════════════════════════════════
HBMB.watermark = async function(src, targetId, options = {}) {
  try {
    // 1. 프로필 읽기
    const profile = await HBMB.load();
    const dogName     = options.dogName      || profile?.dogName      || '';
    const guardianNick= options.guardianNick || profile?.guardianNick || '';

    // 2. 워터마크 텍스트 조합
    // "@보리 보호자님의 전용 자료" 또는 브랜드만
    let nameText = '';
    if (dogName) {
      nameText = `@${dogName} 보호자님의 전용 자료`;
    } else if (guardianNick) {
      nameText = `@${guardianNick}님의 전용 자료`;
    }

    // 3. 이미지 URL 처리
    const imgUrl = src.startsWith('http') ? src : HBMB.img(src);

    // 4. Canvas로 합성
    const result = await _applyWatermark(imgUrl, nameText);

    // 5. 대상 img 태그에 삽입
    const target = document.getElementById(targetId);
    if (target) {
      target.src = result;
    }
    return result;

  } catch(e) {
    console.error('[HBMB Watermark] 오류:', e);
    // 실패 시 원본 이미지라도 표시
    const target = document.getElementById(targetId);
    if (target) target.src = src;
  }
};

// ══════════════════════════════════════
//  여러 이미지 일괄 적용
//  HBMB.watermarkAll(items)
//  items = [{ src, targetId }, ...]
// ══════════════════════════════════════
HBMB.watermarkAll = async function(items, options = {}) {
  const profile = await HBMB.load();
  const merged  = {
    dogName     : profile?.dogName      || '',
    guardianNick: profile?.guardianNick || '',
    ...options
  };
  for (const item of items) {
    await HBMB.watermark(item.src, item.targetId, merged);
  }
};

// ══════════════════════════════════════
//  Canvas 합성 내부 함수
// ══════════════════════════════════════
function _applyWatermark(imgUrl, nameText) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous'; // CORS 허용
    img.onload = () => {
      try {
        // Canvas 생성 (숨김)
        const canvas = document.createElement('canvas');
        canvas.width  = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext('2d');

        // 원본 이미지 그리기
        ctx.drawImage(img, 0, 0);

        // ── 워터마크 영역 계산 ──
        const W  = canvas.width;
        const H  = canvas.height;
        const px = WM_CONFIG.paddingX;
        const py = WM_CONFIG.paddingY;
        const bp = WM_CONFIG.barPadding;

        // 텍스트 측정
        ctx.font = WM_CONFIG.fontBrand;
        const brandW = ctx.measureText(WM_CONFIG.brand).width;

        ctx.font = WM_CONFIG.fontName;
        const nameW = nameText ? ctx.measureText(nameText).width : 0;

        const maxW   = Math.max(brandW, nameW);
        const lineH  = 18;
        const lines  = nameText ? 2 : 1;
        const barW   = maxW + bp * 2;
        const barH   = lineH * lines + bp * 2;
        const barX   = W - barW - px;
        const barY   = H - barH - py;

        // ── 반투명 배경 바 ──
        ctx.save();
        _roundRect(ctx, barX, barY, barW, barH, WM_CONFIG.barRadius);
        ctx.fillStyle = WM_CONFIG.barColor;
        ctx.fill();
        ctx.restore();

        // ── 텍스트 렌더링 ──
        if (nameText) {
          // 이름 텍스트 (위)
          ctx.font      = WM_CONFIG.fontName;
          ctx.fillStyle = WM_CONFIG.colorName;
          ctx.fillText(
            nameText,
            barX + bp,
            barY + bp + lineH - 4
          );
          // 브랜드 텍스트 (아래)
          ctx.font      = WM_CONFIG.fontBrand;
          ctx.fillStyle = WM_CONFIG.colorBrand;
          ctx.fillText(
            WM_CONFIG.brand,
            barX + bp,
            barY + bp + lineH * 2 - 4
          );
        } else {
          // 브랜드만
          ctx.font      = WM_CONFIG.fontBrand;
          ctx.fillStyle = WM_CONFIG.colorBrand;
          ctx.fillText(
            WM_CONFIG.brand,
            barX + bp,
            barY + bp + lineH - 4
          );
        }

        // Canvas → DataURL 변환
        resolve(canvas.toDataURL('image/webp', 0.92));

      } catch(e) { reject(e); }
    };
    img.onerror = () => reject(new Error('이미지 로드 실패: ' + imgUrl));
    img.src = imgUrl;
  });
}

// ── 둥근 사각형 헬퍼 ──
function _roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

console.log('[HBMB] 워터마크 모듈 로드 완료');
